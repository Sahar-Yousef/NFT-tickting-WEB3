import React from "react";
import Clock from "../components/Clock";
import Footer from '../components/footer';
import { createGlobalStyle } from 'styled-components';

const GlobalStyles = createGlobalStyle`
  header#myHeader.navbar.white {
    background: #212428;
  }
`;

const Colection= function() {

const [openMenu, setOpenMenu] = React.useState(true);
const [openMenu1, setOpenMenu1] = React.useState(false);
const handleBtnClick = (): void => {
  setOpenMenu(!openMenu);
  setOpenMenu1(false);
  document.getElementById("Mainbtn").classList.add("active");
  document.getElementById("Mainbtn1").classList.remove("active");
};
const handleBtnClick1 = (): void => {
  setOpenMenu1(!openMenu1);
  setOpenMenu(false);
  document.getElementById("Mainbtn1").classList.add("active");
  document.getElementById("Mainbtn").classList.remove("active");
};
return (
<div>
<GlobalStyles/>

  <section className='container'>
    <div className='row mt-md-5 pt-md-4'>

    <div className="col-md-6 text-center">
                            <img src="./img/items/big-1.jpg" className="img-fluid img-rounded mb-sm-30" alt=""/>
                        </div>
                        <div className="col-md-6">
                            <div className="item_info">
                                Auctions ends in 
                                <div className="de_countdown">
                                  <Clock deadline="December, 30, 2021" />
                                </div>
                                <h2>فعالية فريق احجزها</h2>
                                <div className="item_info_counts">
                                    <div className="item_info_type"><i className="fa fa-image"></i>تقنية</div>
                                    <div className="item_info_views"><i className="fa fa-eye"></i>250</div>
                                    <div className="item_info_like"><i className="fa fa-heart"></i>80</div>
                                </div>
                                <p>عرض لأهم محطات التحليل لنظام احجزها يتبعه طرح الأسئلة عن 
                                    دوافع تطوير احجزها ومناقشة المطورات لشرح التفاصيل التقنية</p>

<h5>عدد التذاكر</h5>
                      <input type="number" name="item_royalties" id="item_royalties" className="form-control" placeholder=" 0"  max="2" min="1"/>
<button type="button" class="btn btn-primary btn-lg"> احجز</button>                                <div className="spacer-40"></div>

                                <div className="de_tab">
                                <div className="de_tab_content">
                                    
                                </div>
                                
                            </div>
                                
                            </div>
                        </div>
    </div>
  </section>

  <Footer />
</div>
);
}
export default Colection;