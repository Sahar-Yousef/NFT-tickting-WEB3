import React, { Component }from "react";
import Clock from "../components/Clock";
import Footer from '../components/footer';
import { createGlobalStyle } from 'styled-components';
import getWeb3 from "../../getWeb3";
import CreateEvent from "../../contracts/CreatEvent.json";

const GlobalStyles = createGlobalStyle`
  header#myHeader.navbar.white {
    background: #212428;
  }
`;

// const Colection = function() {
  export default class Colection extends Component {
    state = {
      NumOfTicket: null,
      value: null,
      web3: null,
      accounts: null,
      contract: null,
  };
// const [openMenu, setOpenMenu] = React.useState(true);
// const [openMenu1, setOpenMenu1] = React.useState(false);
// const [NumOfTicket, setNumOfTicket] = React.useState();

// const[]

componentDidMount = async () => {
    
  try {
    // Get network provider and web3 instance.
    const web3 = await getWeb3();

    // Use web3 to get the user's accounts.
    const accounts = await web3.eth.getAccounts();

    // Get the contract instance.
  //   const networkId = await web3.eth.net.getId();
  //   const deployedNetwork = Storage.networks[networkId];
    const instance = new web3.eth.Contract(
      CreateEvent, //API json file
      "0x199840F8172aAEdbf65621eB305a607fDC8D3871", //contract address
      
    );

    // Set web3, accounts, and contract to the state, and then proceed with an
    // example of interacting with the contract's methods.
    this.setState({ web3, accounts, contract: instance }, this.runExample);
  } catch (error) {
    // Catch any errors for any of the above operations.
    alert(
      `Failed to load web3, accounts, or contract. Check console for details.`,
    );
    console.error(error);
    
  }
};
// componentDidMount();

Send = async(event) =>{
  event.preventDefault();
  const {accounts, contract} = this.state;
  if(contract === undefined) {return}
  console.log(contract.methods)
  await contract.methods.buyTicket("0", accounts[0], this.state.NumOfTicket).send({from: accounts[0]});
  }


// const handleBtnClick = (): void => {
//   setOpenMenu(!openMenu);
//   setOpenMenu1(false);
//   document.getElementById("Mainbtn").classList.add("active");
//   document.getElementById("Mainbtn1").classList.remove("active");
// };
// const handleBtnClick1 = (): void => {
//   setOpenMenu1(!openMenu1);
//   setOpenMenu(false);
//   document.getElementById("Mainbtn1").classList.add("active");
//   document.getElementById("Mainbtn").classList.remove("active");
// };



render() {

return (
<div>
<GlobalStyles/>

  <section className='container'>
    <div className='row mt-md-5 pt-md-4'>

    <div className="col-md-6 text-center">
                            <img src="./img/items/big-1.jpg" className="img-fluid img-rounded mb-sm-30" alt=""/>
                        </div>
                        <div className="col-md-6">
                            <div className="item_info">

                                <h2>فعالية فريق احجزها</h2>
                                <div className="item_info_counts">
                                    <div className="item_info_type"><i className="fa fa-image"></i>تقنية</div>
                                    <div className="item_info_views"><i className="fa fa-eye"></i>250</div>
                                    <div className="item_info_like"><i className="fa fa-heart"></i>80</div>
                                </div>
                                <p>عرض لأهم محطات التحليل لنظام احجزها يتبعه طرح الأسئلة عن 
                                    دوافع تطوير احجزها ومناقشة المطورات لشرح التفاصيل التقنية</p>

                                <h5>عدد التذاكر</h5>
                                  <input type="number" name="item_royalties" id="item_royalties" onChange={(e) => this.setState({NumOfTicket: e.target.value})} className="form-control" placeholder=" 0"  max="2" min="1"/>
                                <button type="button" class="btn btn-primary btn-lg" onClick={this.Send}> احجز</button>                                <div className="spacer-40"></div>

                                <div className="de_tab">
                                <div className="de_tab_content">
                                    
                                </div>
                                
                            </div>
                                
                            </div>
                        </div>
    </div>
  </section>

  <Footer />
</div>
);
}
}

// export default Colection;
