

    import * as IPFS from 'ipfs-core';

    async function main() {
    const node = await IPFS.create();
    }
    
    main();