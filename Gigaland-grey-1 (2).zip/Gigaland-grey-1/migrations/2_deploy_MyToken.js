// var  artifacts    = require("truffle", "./Tickets.sol");
// var Tickets = artifacts;
// .require("./Tickets.sol");
const MyToken = artifacts.require( "./MyToken.sol");

module.exports = function(deployer) {
  deployer.deploy(MyToken);
  };
  
